package com.londonappbrewery.quizzler;

public class TrueFalse {
    private int myqID;
    boolean answer;

    TrueFalse(int id, boolean tf){
        myqID=id;
        answer=tf;
    }

    public int getMyqID() {
        return myqID;
    }

    public void setMyqID(int myqID) {
        this.myqID = myqID;
    }

    public boolean isAnswer() {
        return answer;
    }

    public void setAnswer(boolean answer) {
        this.answer = answer;
    }
}
