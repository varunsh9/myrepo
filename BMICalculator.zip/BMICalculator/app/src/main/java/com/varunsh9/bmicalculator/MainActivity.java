package com.varunsh9.bmicalculator;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText height = (EditText)findViewById(R.id.height);
        final EditText mass = (EditText)findViewById(R.id.weight);
        final Button btn = (Button)findViewById(R.id.calculateButton);
        final TextView txt = (TextView)findViewById(R.id.res);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = Float.valueOf(mass.getText().toString());
                float y = Float.valueOf(height.getText().toString());
                float _bmi = setText(x,y);
                txt.setText(Float.toString(_bmi));
                String text;
                if(_bmi>=25){
                    text="Overweight";
                }else if(_bmi<25 && _bmi>18.5){
                    text="Normal Weight";
                }else{
                    text="Underweight";
                }
                txt.setText("Your BMI is : " + _bmi + " " + text);

                try  {
                    InputMethodManager imm =
                            (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                } catch (Exception e) {

                }
            }
        });
    }

    float setText(float m, float h){
        float bmi = m/(h*h);
        return bmi;
    }
}
